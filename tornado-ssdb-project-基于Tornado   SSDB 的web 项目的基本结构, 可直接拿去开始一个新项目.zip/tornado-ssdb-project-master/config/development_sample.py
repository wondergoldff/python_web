# -*- coding: utf-8 -*-

from .default import Config


class DevelopmentConfig(Config):
    pass
