# tornado-ssdb-project
这是一个基于Tornado + SSDB 的web 项目的基本结构, 你可以直接拿它去开始一个新的项目, 如果遇到问题可以直接上论坛 [http://www.pylist.com/](http://www.pylist.com/) 提出。